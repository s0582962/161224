#! /usr/bin/python3
#! /usr/bin/python3
###########################################################################
# Github-Name: s0582962
# Name: Sidar Taskiran
# Email: sidar.taskiran@student.htw-berlin.de
# Punkte: xx/44
# Abgabe: 07.12.2022
#############################################################################
import sys
from queue import Queue

class Read:
    def __init__(self, lines):
        self.name = lines[0].strip()[1:]
        self.bases = "".join([x.strip() for x in lines[1:]]).upper()

    def get_kmers(self, kmersize):
        res = {}
        for pos in range(0, len(self.bases) - kmersize + 1):
            kmer = self.bases[pos:(pos + kmersize)]
            if kmer not in res:
                res[kmer] = 0
            res[kmer] += 1
        return res

    def __str__(self):
        return self.name + ": " + self.bases[:20] + "..."

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        if not isinstance(other, Read):
            return False
        if other.name == self.name and other.bases == self.bases:
            return True
        return False


class DBGnode:
    def __init__(self, seq):
        self.seq = seq
        self.eto = dict()
        self.efrom = dict()

    def add_edge_to(self, eto):
        if eto not in self.eto:
            self.eto[eto] = 0
        self.eto[eto] += 1

    def add_edge_from(self, efrom):
        if efrom not in self.efrom:
            self.efrom[efrom] = 0
        self.efrom[efrom] += 1
    def remove_edge_to(self, eto):
        if eto in self.eto:
            #self.efrom[eto] -= 1
            #if self.efrom[eto] <1:
            self.eto.pop(eto)


    def remove_edge_from(self, efrom):
        if efrom in self.efrom:
            self.efrom.pop(efrom)
            pass
        pass


    def get_potential_from(self):
        res = []
        for x in "AGTC":
            res += [x + self.seq[:-1]]
        return res

    def get_potential_to(self):
        res = []
        for x in "AGTC":
            res += [self.seq[1:] + x]
        return res

    def get_edge_to_weight(self, other):
        if not other in self.eto:
            return 0
        return self.eto[other]

    def get_edge_from_weight(self, other):
        if not other in self.efrom:
            return 0
        return self.efrom[other]
    def get_seq(self):
        return self.seq

    # 6 Punkte
    def extend_next(self):
        if self.can_extend_next() == False:                                                                  # or self.eto in self.extension:
            return None
        key = list(self.eto.keys())

#        copy=self
        self.seq = self.combine(self.seq, key[0].get_seq())  ##Erweitern von self.seq mittels Hilfsfunktion


        for i in key[0].eto:     # eto und self werden entsprechend gegenseitig als Edges hinzugefügt
            self.eto={}             #lösche eigenes eto dict
            self.add_edge_to(i)     #übernehme edges vom hinzugefügten Key


            for j in key[0].efrom:
                i.add_edge_from(j)     #self wird allen etos von efrom hinzugefügt

        #for key in self.efrom.keys():
        #    key[0].add_edge_from(key)

        return key[0]  # am Ende muss die eto-DBGnode returnt werden
    # 6 Punkte
    def extend_prev(self):
        if self.can_extend_prev() == False:  #überprüfe ob geht
            return None
        key = list(self.efrom.keys())   #key[0] ist die DBGnode, um die Erweitert wird

#        copy=self
        self.seq=self.combine(key[0].get_seq(), self.seq)            ##Erweitern von self.seq mittels Hilfsfunktion

        for i in key[0].efrom:      #efrom und self werden entsprechend gegenseitig als Edges hinzugefügt
            self.efrom={}
            self.add_edge_from(i)   #Edges von efrom werden übernommen (weil self.seq jetzt selben Anfang hat)

            for j in key[0].eto:
                i.add_edge_to(j)  # self wird allen etos von efrom hinzugefügt


        return key[0]       #am Ende muss die efrom-DBGnode returnt werden

    #hilfs-Funktion
    def combine(self, frome, eto):
        puffer1=""
        for i in range(len(eto) - len(frome)): #if frome < eto:
            puffer1+="/"
        frome = puffer1 + frome

        for i in range(len(frome)):         #! ! Annahme: Länge von frome >= eto
            fc = frome[len(frome) - 1]  #aktueller Char von to wird immer mit letztem char...
            ct = eto[len(eto) - 1 - i]  #...von from verglichen (fängt von Hinten an)
            gemeinsameChars=""
            if fc == ct:             #mögliche Schnittstelle gefunden

                puffer2=""
                for j in range(len(frome) - len(eto)):  # if frome > eto:
                    puffer2 += "/"
                eto = puffer2 + eto


                for j in range(len(eto)):
                    fc = frome[len(frome) - 1 - j]  #überprüfe wie lange die chars von...
                    ct = eto[len(eto) - 1 - i - j]  #...from und to gleich bleiben
                    if fc != ct or j==len(eto)-1:       #bei Unterschied enden die Gemeinsamen Chars...
                                                        #...oder wenn der counter "j" bis an den...
                                                        #...-1sten Index von eto gelangt ist
                        result = frome[len(puffer1):] + eto[j+len(puffer2):]    ##result setzt sich aus dem gesamten from + den...
                        result.strip("/")
                        return result
                        #print(result)
                        #break                       #...Stellen von to, ab dem Index, wo die Gemeinsamen Chars enden
                    gemeinsameChars+=ct
            else:
                continue
        return None

    # 3 Punkte
    def can_extend_next(self):
        key = list(self.eto.keys())
        if len(self.eto) != 1:            #kann nicht extenden wenn seq mehrere etos hat
            return False
        if len(key[0].efrom) !=1:   #kann nicht extenden wenn eto mehrere efroms hat
            return False
        if key[0].get_seq() == self.seq:    #kann nicht extenden wenn eto == seq
            return False
        return True

    # 3 Punkte
    def can_extend_prev(self):
        key = list(self.efrom.keys())
        if len(self.efrom) != 1:            #kann nicht extenden wenn seq mehrere efroms hat
            return False
        if len(key[0].eto) != 1:            #kann nicht extenden wenn efrom mehrere etos hat
            return False
        if key[0].get_seq() == self.seq:    #kann nicht extenden wenn efrom == seq
            return False
        return True

class DBGraph:
    def __init__(self):
        self.nodes = {}     #Contigs sind Nodes die man nicht erweitern kann
        self.kmerlen = None

        self.isSimp = False
        #self.n50=""
        """n50= Maß mit dem man Qualität des Assamblys bestmmen kann. "Median" 
        die Länge des Contigs dessen kommulative Summe 50% der Läge ller Kontigs überschreitet. Nur der Erste der in Sortierten Liste ist"""

    def add_kmers(self, kmers):
        if self.isSimp==True:
            return None

        if len(kmers) == 0:
            return
        ## Falls kmer-Länge (Dimension) des Graphen noch nicht gesetzt ist,
        ## auf den Wert von irgendeinem k-mer aus der übergebenen dictionary
        ## setzen.
        if self.kmerlen is None:
            self.kmerlen = len(next(iter(kmers.keys())))
        for kmer_s in kmers.keys():
            if len(kmer_s) != self.kmerlen:
                raise ValueError("Incompatible k-mer lengths: " + str(self.kmerlen) + " and " + str(len(kmer_s)))
            if kmer_s not in self.nodes.keys():
                self.nodes[kmer_s] = DBGnode(kmer_s)
            kmer = self.nodes[kmer_s]
            ## Für jedes mögliche k-mer, von/zu dem es eine Kante geben könnte,
            ## die entsprechenden Kanten hinzufügen, falls dieses k-mer auch im
            ## Graphen ist (vorsicht: wenn es eine Kante A -> B gibt, sowohl in
            ## A eine kante nach B als auch in B eine Kante von A hinzufügen)
            for pto in kmer.get_potential_to():
                if pto in self.nodes.keys():
                    self.nodes[pto].add_edge_from(kmer)
                    kmer.add_edge_to(self.nodes[pto])
            for pfrom in kmer.get_potential_from():
                if pfrom in self.nodes.keys():
                    self.nodes[pfrom].add_edge_to(kmer)
                    kmer.add_edge_from(self.nodes[pfrom])

    def count_edges(self):
        edges = 0
        for kmer, node in self.nodes.items():
            edges += len(node.eto)
        return edges

    def count_nodes(self):
        return len(self.nodes)

    #12 Punkte  ['ATG', 'TGC', 'GCG', 'CGT', 'GTA', 'TAG', 'AGC'] -> ['ATGC', 'GCGTAGC']
    def simplify(self):
        result =self.nodes.copy()
        def tuell_rein(result,tuell):
            copy = {}
            for kmer, node in tuell.items():
                result.pop(kmer)
                copy.update({node.get_seq(): node})
            for kmer, node in result.items():
                copy.update({node.get_seq(): node})
            result = copy
            return result
        def muell_raus(result,muell):
            for m in muell:
                result.pop(m.get_seq())
                for kmer,node in result.items():
                    node.remove_edge_from(m)
                    node.remove_edge_to(m)
            return result

        while self.isSimp==False:
            #gehe durch nodes um alle möglichen zu verknüpfen
            kmers = list(result)
            nodes = list(result.values())
            count = 0

            tuell={}                #für die DBs die sich erweitern  und bleiben
            muell=[]                #für die Dbs um die Erweitert wird  und gehen
            for kmer, node in result.items():

                #extenden wenn geht und to in den muell
                efrom = node.extend_prev()
                if efrom != None:
                    if efrom.get_seq() in result.keys():
                        muell.append(efrom)
                eto = node.extend_next()
                if eto != None:
                    if eto.get_seq() in result.keys():
                        muell.append(eto)
                        # ! ! remove muell from all efroms

                tuell.update({kmer:node})
                if eto != None or efrom != None:
                    break
                else:
                    count+=1

            result = muell_raus(result,muell)   ##überflüssige nodes rauswerfen
            result = tuell_rein(result,tuell)   ##Gute Nodes rein

            if count == len(kmers):
                self.isSimp=True

        self.nodes = result

        #gehe über jede Node
        #alle nodes miteinander extenden
        #zusätzlich Queue erstellen
        #wenn gemerged wurden wieder in Queue rein, der andere raus
        #Node aus Debrujin löschen um den Erweitert wurde




    #2 Punkte + 1 Zusatz wenn in einer Zeile!
    def get_FASTA(self):
        #return (">".join([y.strip() for y in x.split("\n")[1:]]) for x in self.nodes[1:])
        result=""
        count = 0
        for kmer in self.nodes:
            count += 1
            result+=">Read "+str(count)+"\n"+kmer+"\n"
        return result

    #1 Punkt
    def get_numContigs(self):   #Anzahl aller Contigs
        if self.isSimp==False:
            return None
        return len(self.nodes)  #wenn Graph simplified wurde, sind alle nodes Contigs

    #3 Punkte
    def get_N50(self):  #Erster Contig(in Cumsum) der
        if self.isSimp == False:
            return None

        result=0
            #nodes = list(self.nodes)
        contigLengths = []  #List für Länge der Sequenzen
        kmerLength=0         #Gesamtlänge ergibt sich aus allen Nodes

        for kmer in self.nodes:
            contigLengths.append(len(kmer))   #Hinzufügen der Längen der Sequenzen
            kmerLength+=len(kmer)
        contigLengths.sort(reverse=True)        #Sortieren der Längen Größer -> Kleiner

        count=0
        for i in contigLengths:         #finde contig der größer als kmerLength ist
            count+=i
            if count >= kmerLength/2:
                result  =i
                break
        return result

    def __str__(self):
        return "DBG(" + str(self.kmerlen) + ") with " + str(self.count_nodes()) + " nodes and " + str(
            self.count_edges()) + " edges"


def read_fasta(readfile):
    f = open(readfile, "r")
    readlines = []
    reads = []
    for line in f:
        readlines += [line]
        if len(readlines) == 2:
            reads += [Read(readlines)]
            readlines = []
    f.close()
    return reads


def build_graph(filename, kmersize):
    reads = read_fasta(filename)
    graph = DBGraph()
    for read in reads:
        graph.add_kmers(read.get_kmers(kmersize))
    return graph

# Blast ergebnis 2 punkte
# Screenshot 2 punkte
# Verwendete Kmer länge 3 Punkte
# Resultierendes Fasta file: 1 Punkt


if __name__ == "__main__":
    kmersize=39
    dbg = build_graph("data/virus_perfectreads.fasta", kmersize)
    print(dbg)
    dbg.simplify()
    print(dbg)
    print(dbg.get_FASTA())