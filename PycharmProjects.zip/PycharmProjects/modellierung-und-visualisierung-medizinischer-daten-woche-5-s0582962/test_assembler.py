from unittest import TestCase
import pytest
from os.path import exists
import hashlib


from assembler import Read, DBGnode, DBGraph
import assembler

class AssemblerTestCase(TestCase):

    @pytest.mark.read
    def test_read_constructor(self):
        read = Read([">Read 1", "AGTCGTAGC"])
        self.assertEqual("Read 1", read.name)
        self.assertEqual("AGTCGTAGC", read.bases)

    @pytest.mark.read
    def test_read_str(self):
        read = Read([">Read 2", "AGTCGTAGCGTACCGTAGCCCGTTGGCAGTA"])
        self.assertEqual("Read 2: AGTCGTAGCGTACCGTAGCC...", str(read))

    def test_read_repr(self):
        read = Read([">Read 3", "AGTCGTAGCGTGTCCGACGTAGCCCGTTGGCAGTA"])
        self.assertEqual(str(read), read.__repr__())
        read = Read([">Read 3", "CCT"])
        self.assertEqual(str(read), read.__repr__())

    @pytest.mark.read
    def test_read_get_kmers(self):
        read = Read([">Read", "AGTCGTAGTC"])
        self.assertEqual({'AGTC': 2, 'GTCG': 1, 'TCGT': 1, 'CGTA': 1, 'GTAG': 1, 'TAGT': 1}, read.get_kmers(4))
        read = Read([">Read", "AGT"])
        self.assertEqual({}, read.get_kmers(4))
        read = Read([">Read", "AGTCGTACCGTGACGTACGAT"])
        self.assertEqual({'A': 5, 'G': 6, 'T': 5, 'C': 5}, read.get_kmers(1))

    @pytest.mark.read
    def test_read_eq(self):
        read1 = Read([">Read", "AGTCGTAGTC"])
        read2 = Read([">Read", "AGTCGTAGTC"])
        read3 = Read([">Read", "AGTCGTGGTC"])
        self.assertTrue(read1 == read2)
        self.assertFalse(read1 == read3)
        self.assertFalse(read1 == "test")

    @pytest.mark.dbgnode
    def test_dbgnode_get_potential_from(self):
        node = DBGnode("AGTC")
        self.assertEqual(set(["AAGT", "GAGT", "TAGT", "CAGT"]), set(node.get_potential_from()))

    @pytest.mark.dbgnode
    def test_dbgnode_get_potential_to(self):
        node = DBGnode("TAC")
        self.assertEqual(set(["ACA", "ACG", "ACT", "ACC"]), set(node.get_potential_to()))

    @pytest.mark.dbgnode
    def test_dbgnode_add_edge_to(self):
        node1 = DBGnode("TAC")
        node2 = DBGnode("ACA")
        node3 = DBGnode("ACG")
        node1.add_edge_to(node2)
        self.assertEqual(0, node1.get_edge_to_weight(node1))
        self.assertEqual(1, node1.get_edge_to_weight(node2))
        self.assertEqual(0, node1.get_edge_to_weight(node3))
        node1.add_edge_to(node2)
        self.assertEqual(0, node1.get_edge_to_weight(node1))
        self.assertEqual(2, node1.get_edge_to_weight(node2))
        self.assertEqual(0, node1.get_edge_to_weight(node3))
        node1.add_edge_to(node3)
        self.assertEqual(0, node1.get_edge_to_weight(node1))
        self.assertEqual(2, node1.get_edge_to_weight(node2))
        self.assertEqual(1, node1.get_edge_to_weight(node3))
        node1.add_edge_to(node1)
        self.assertEqual(1, node1.get_edge_to_weight(node1))
        self.assertEqual(2, node1.get_edge_to_weight(node2))
        self.assertEqual(1, node1.get_edge_to_weight(node3))

    @pytest.mark.dbgnode
    def test_dbgnode_add_edge_from(self):
        node1 = DBGnode("TAC")
        node2 = DBGnode("ATA")
        node3 = DBGnode("GTA")
        node1.add_edge_from(node2)
        self.assertEqual(0, node1.get_edge_from_weight(node1))
        self.assertEqual(1, node1.get_edge_from_weight(node2))
        self.assertEqual(0, node1.get_edge_from_weight(node3))
        node1.add_edge_from(node2)
        self.assertEqual(0, node1.get_edge_from_weight(node1))
        self.assertEqual(2, node1.get_edge_from_weight(node2))
        self.assertEqual(0, node1.get_edge_from_weight(node3))
        node1.add_edge_from(node3)
        self.assertEqual(0, node1.get_edge_from_weight(node1))
        self.assertEqual(2, node1.get_edge_from_weight(node2))
        self.assertEqual(1, node1.get_edge_from_weight(node3))
        node1.add_edge_from(node1)
        self.assertEqual(1, node1.get_edge_from_weight(node1))
        self.assertEqual(2, node1.get_edge_from_weight(node2))
        self.assertEqual(1, node1.get_edge_from_weight(node3))

    @pytest.mark.dbgraph
    def test_dbgraph_correct(self):
        kmers = {"AGT": 2, "GTC": 1, "TCA": 2, "GTG": 3}
        graph = DBGraph()
        graph.add_kmers(kmers)
        self.assertEqual(3, graph.count_edges())

    @pytest.mark.dbgraph
    def test_dbgraph_wrongkmer(self):
        kmers = {"AGT": 2, "GTC": 1, "TCAA": 2, "GTG": 3}
        graph = DBGraph()
        with pytest.raises(ValueError):
            graph.add_kmers(kmers)

    @pytest.mark.toplevel
    def test_read_fasta(self):
        expected = [Read([">1", "AGTCTAC"]), Read([">2", "TCTACCG"])]
        self.assertEqual(expected, assembler.read_fasta("data/test.fasta"))

    @pytest.mark.toplevel
    def test_build_graph(self):
        graph = assembler.build_graph("data/test.fasta", 2)
        self.assertEqual(8, graph.count_nodes())
        self.assertEqual(17, graph.count_edges())
        graph = assembler.build_graph("data/test.fasta", 4)
        self.assertEqual(6, graph.count_nodes())
        self.assertEqual(5, graph.count_edges())
        graph = assembler.build_graph("data/virus_perfectreads.fasta", 6)
        self.assertEqual(1581, graph.count_nodes())
        self.assertEqual(3644, graph.count_edges())
        graph = assembler.build_graph("data/virus_perfectreads.fasta", 12)
        self.assertEqual(2418, graph.count_nodes())
        self.assertEqual(2418, graph.count_edges())

    @pytest.mark.simplifiy  #passed
    def test_dbgraph_simplify(self):        #passed
        graph = DBGraph()
        graph.add_kmers(Read([">read", "ATGCGTAGC"]).get_kmers(3))
        self.assertEqual(7, graph.count_edges())
        self.assertEqual(7, graph.count_nodes())
        graph.simplify()
        self.assertEqual(2, graph.count_edges())
        self.assertEqual(2, graph.count_nodes())
        seqs = [x for x in graph.nodes]
        self.assertTrue("ATGC" in seqs, "Expected sequence 'ATGC' in returned FASTA: \n" + '\n'.join(seqs))
        self.assertTrue("GCGTAGC" in seqs, "Expected sequence 'ATGC' in returned FASTA: \n" + '\n'.join(seqs))

    @pytest.mark.N50
    def test_dbgraph_N50(self):
         graph = DBGraph()
         graph.add_kmers(Read([">read", "ATGCGTAGC"]).get_kmers(3))
         graph.add_kmers(Read([">read", "CCC"]).get_kmers(3))
         graph.add_kmers(Read([">read", "TTT"]).get_kmers(3))
         graph.simplify()
         self.assertEqual(4, graph.get_N50())

    @pytest.mark.contigCount        #done
    def test_dbgraph_numContigs(self):      #passed
        graph = DBGraph()
        graph.add_kmers(Read([">read", "ATGCGTAGC"]).get_kmers(3))
        graph.simplify()
        self.assertEqual(2, graph.get_numContigs())



    @pytest.mark.fastaout
    def test_dbgraph_getFASTA(self):
        graph = DBGraph()
        graph.add_kmers(Read([">read", "ATGCGTAGC"]).get_kmers(3))
        graph.simplify()
        fasta = graph.get_FASTA()
        seqsInFasta = ["".join([y.strip() for y in x.split("\n")[1:]]) for x in fasta.split(">")[1:]]
        self.assertTrue(len(seqsInFasta) == 2)
        self.assertTrue("ATGC" in seqsInFasta, "Expected sequence 'ATGC' in returned FASTA: \n" + fasta)
        self.assertTrue("GCGTAGC" in seqsInFasta, "Expected sequence 'GCGTAGC' in returned FASTA: \n" + fasta)

    @pytest.mark.simplifykmerlock   #passed
    def test_adding_kmer_after_simplyfy(self):
        graph = DBGraph()
        graph.add_kmers(Read([">read", "AAA"]).get_kmers(3))
        graph.simplify()
        try:
            graph.add_kmers(Read([">read", "TTTT"]).get_kmers(3))
        finally:
            pass
        self.assertEqual(1, len(graph.nodes),"Es duerfen keine kmere mehr hinzugefügt werden nach der Simplifizierung!")


    @pytest.mark.can_extend_next    #passed
    def test_dbgnode_can_extend_next(self): #done
        node1 = DBGnode("AGA")
        node2 = DBGnode("GGT")
        node3 = DBGnode("GTA")
        node4 = DBGnode("TAG")
        node5 = DBGnode("AGC")
        node1.add_edge_to(node2)
        node2.add_edge_to(node3)
        node3.add_edge_to(node4)
        node4.add_edge_to(node1)
        node4.add_edge_to(node5)
        node1.add_edge_from(node4)
        node2.add_edge_from(node1)
        node3.add_edge_from(node2)
        node4.add_edge_from(node3)
        node5.add_edge_from(node4)
        self.assertTrue(node1.can_extend_next())
        self.assertTrue(node2.can_extend_next())
        self.assertTrue(node3.can_extend_next())
        self.assertFalse(node4.can_extend_next())
        self.assertFalse(node5.can_extend_next())

        node6 = DBGnode("AAA")
        node6.add_edge_from(node6)
        node6.add_edge_to(node6)
        self.assertFalse(node6.can_extend_next(), "exclude loops!")


    @pytest.mark.can_extend_prev    #passed
    def test_dbgnode_can_extend_prev(self): #done
        node1 = DBGnode("AGA")
        node2 = DBGnode("GGT")
        node3 = DBGnode("GTA")
        node4 = DBGnode("TAG")
        node5 = DBGnode("AGC")
        node1.add_edge_to(node2)
        node2.add_edge_to(node3)
        node3.add_edge_to(node4)
        node4.add_edge_to(node1)
        node4.add_edge_to(node5)
        node1.add_edge_from(node4)
        node2.add_edge_from(node1)
        node3.add_edge_from(node2)
        node4.add_edge_from(node3)
        node5.add_edge_from(node4)

        node6 = DBGnode("AAA")
        node6.add_edge_from(node6)
        node6.add_edge_to(node6)

        self.assertFalse(node1.can_extend_prev())
        self.assertTrue(node2.can_extend_prev())
        self.assertTrue(node3.can_extend_prev())
        self.assertTrue(node4.can_extend_prev())
        self.assertFalse(node5.can_extend_prev())
        self.assertFalse(node6.can_extend_prev(), "exclude loops!")


    @pytest.mark.extend_prev    #passed
    def test_dbgnode_extend_prev(self): #done
        # AGA -> GAT -> ATC-,
        # ^_________________|
        node1 = DBGnode("AGA")
        node2 = DBGnode("GAT")
        node3 = DBGnode("ATC")
        node1.add_edge_to(node2)
        node2.add_edge_from(node1)
        node2.add_edge_to(node3)
        node3.add_edge_from(node2)
        node3.add_edge_to(node1)
        node1.add_edge_from(node3)
        self.assertEqual(0, node3.get_edge_to_weight(node2))
        x = node2.extend_prev()
        # AGAT ->  ATC
        # ^_________|
        self.assertEqual("AGA", x.seq)
        self.assertEqual("AGAT", node2.seq)
        self.assertEqual(1, node3.get_edge_to_weight(node2))
        x = node3.extend_prev()
        # AGATC
        # ^___|
        self.assertEqual("AGATC", node3.seq)
        self.assertEqual("AGAT", x.seq)
        self.assertEqual(1, node3.efrom[node3])
        self.assertEqual(1, node3.eto[node3])
        x = node3.extend_prev()
        self.assertEqual(None, x)

    @pytest.mark.extend_next    #passed
    def test_dbgnode_extend_next(self):     #done
        # AGA -> GAT -> ATC-,
        # ^_________________|
        node1 = DBGnode("AGA")
        node2 = DBGnode("GAT")
        node3 = DBGnode("ATC")
        node1.add_edge_to(node2)
        node2.add_edge_from(node1)
        node2.add_edge_to(node3)
        node3.add_edge_from(node2)
        node3.add_edge_to(node1)
        node1.add_edge_from(node3)
        self.assertEqual(0, node2.get_edge_to_weight(node1))
        x = node2.extend_next()
        # AGA -> GATC
        # ^_________|
        self.assertEqual("ATC",x.seq)
        self.assertEqual("GATC", node2.seq)
        self.assertEqual(1, node2.get_edge_to_weight(node1))
        x = node1.extend_next()
        # AGATC
        # ^___|
        self.assertEqual("AGATC", node1.seq)
        self.assertEqual("GATC", x.seq)
        x = node1.extend_next()
        self.assertEqual(None, x)


    @pytest.mark.blastResult
    def test_blast_result(self):
        hash = '20ef9ba110b3d1c3bbc514446fd6d47522e6ffd38674da39a56cb020c308b506dc254e722147d703c633b35c96ac5cb7c353ed8dfbd8072cecba2a4e3cd666df'
        hashesBeMoreSpecific = [
            'deb4b9b745ab32239ba79f31707d1aa67df0329fe7d0be384bb0677b977eb4a472819ad0df18be91aa29926a189588f9e2f3e3cbb29f43bbe26517d4fb2d784a',
            '39041df23474ba759462f3910d7db3ec28365d5b05a177ebac29e93b32da8a2ed582bfe7705b43635df641dd2a2736dbcc81b897936e89447bd8ebcb08649c1b'
        ]

        with open("README.md", "r", encoding="UTF-8") as resDE:
            for line in resDE:
                if line.startswith("Die Sequenzen aus virus_perfectreads.fasta stammen vermutlich aus dem Virus:"):
                    res = line.split("Die Sequenzen aus virus_perfectreads.fasta stammen vermutlich aus dem Virus:")[1].strip().encode()
                    if res != b"XXXX":
                        rhash = hashlib.sha512(res).hexdigest()
                        self.assertFalse(rhash in hashesBeMoreSpecific, "Ihre Angabe (%s) ist nicht spezifisch genug!"% (res.decode()))
                        self.assertEqual(rhash, hash, "Hash-Wert des gefundenen Organismus (%s) stimmt nicht Überein."%(res.decode()))
                        return True

        with open("README_en.md", "r", encoding="UTF-8") as resDE:
            for line in resDE:
                if line.startswith("The sequences from virus_perfectreads.fasta most likely come from the virus:"):
                    res = line.split("The sequences from virus_perfectreads.fasta most likely come from the virus:")[1].strip().encode()
                    if res != b"XXXX":
                        rhash = hashlib.sha512(res).hexdigest()
                        self.assertFalse(rhash in hashesBeMoreSpecific, "(%s) is not specific enougth"%(res.decode()))
                        self.assertEqual(rhash, hash,
                                         "Hash-Value of (%s) does not match." % (res.decode()))
                        return True
        self.assertTrue(False, "Blast Result in README is still XXXX")

    @pytest.mark.blastScreenshot
    def test_screenshot_presence(self):
        hash = 'e937715bd71cd6765c70e30ece01dcf60134397bfbc386423ad9348a4d12bb909a648a4ee89ecb6bf6e309fdfb51de5b3f7b4fdd8eae1a4b4b0edeb2178f3093'
        self.assertTrue(exists("Bilder/BLAST-Ergebnis.png"), "'Bilder/BLAST-Ergebnis.png' not found in Repository")
        with open ("Bilder/BLAST-Ergebnis.png","rb") as sc:
            self.assertNotEqual(hashlib.sha512(sc.read()).hexdigest(), hash, "\nScreenshot-file not modified! Please Upload your Blast screenshot!")



    @pytest.mark.blastResultkmerSize
    def test_blast_resultkmerSize(self):
        with open("README.md", "r", encoding="UTF-8") as resDE:
                for line in resDE:
                    if line.startswith("Verwendete k-mer-Länge:"):
                        res = line.split("Verwendete k-mer-Länge:")[1].strip().encode()
                        if res != b"XXX":
                            return True

        with open("README_en.md", "r", encoding="UTF-8") as resDE:
                for line in resDE:
                    if line.startswith("Used k-mer length:"):
                        res = line.split("Used k-mer length:")[1].strip().encode()
                        if res != b"XXX":
                            return True
        self.assertTrue(False, "Blast kmer len missing")

    @pytest.mark.blastResultFasta
    def test_blast_resultFasta(self):
        test = False
        with open("README.md", "r", encoding="UTF-8") as resDE:
                for line in resDE:
                    if line.startswith("...."):
                        with open("README_en.md", "r", encoding="UTF-8") as resEN:
                            for line in resEN:
                                self.assertFalse(line.startswith("...."), "Verwendetetes Fasta File fehlt!")
                        break



