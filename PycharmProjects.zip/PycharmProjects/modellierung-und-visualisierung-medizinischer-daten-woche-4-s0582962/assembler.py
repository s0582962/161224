#! /usr/bin/python3
###########################################################################
# Github-Name: s0582962
# Name: Sidar Taskiran
# Email: sidar.taskiran@student.htw-berlin.de
# Punkte: xx/17
#############################################################################
#Textaufgabe: siehe unten
class Read:
    def __init__(self, lines):
        self.name = lines[0].strip()[1:]
        self.bases = "".join([x.strip() for x in lines[1:]]).upper()

    def get_kmers(self, kmersize):
        res = {}
        for pos in range(0, len(self.bases) - kmersize + 1):
            kmer = self.bases[pos:(pos + kmersize)]
            if kmer not in res:
                res[kmer] = 0
            res[kmer] += 1
        return res

    def __str__(self):
        return self.name + ": " + self.bases[:20] + "..."

    def __repr__(self):
        return self.__str__()

    def __eq__(self, other):
        if not isinstance(other, Read):
            return False
        if other.name == self.name and other.bases == self.bases:
            return True
        return False


class DBGnode:
    def __init__(self, seq):
        self.seq = seq
        self.eto = dict()
        self.efrom = dict()

    def add_edge_to(self, eto):
        if eto not in self.eto:
            self.eto[eto] = 0
        self.eto[eto] += 1

    def add_edge_from(self, efrom):
        if efrom not in self.efrom:
            self.efrom[efrom] = 0
        self.efrom[efrom] += 1

    def get_potential_from(self):
        res = []
        for x in "AGTC":
            res += [x + self.seq[:-1]]
        return res

    def get_potential_to(self):
        res = []
        for x in "AGTC":
            res += [self.seq[1:] + x]
        return res

    def get_edge_to_weight(self, other):
        if not other in self.eto:
            return 0
        return self.eto[other]

    def get_edge_from_weight(self, other):
        if not other in self.efrom:
            return 0
        return self.efrom[other]


class DBGraph:    # 2 Punkte
    def __init__(self):
        self.nodes = dict()
        self.kmerlength = 0        #wird bei ersten add_kmer geändert (einmalig)
        self.edges = set()        #edges
        #self.allKmers = []
    # 8 Punkte
    def add_kmers(self, kmers):
        for key in kmers:
            if self.kmerlength == 0:  # bestimmt die kmer-länge an der sich der Rest richten muss
                self.kmerlength = len(key)
            if len(key) != self.kmerlength:  # überprüft ob Länge des kmers zum Rest passt
                raise ValueError("Länge des k-mers stimmt nicht überein.")
            #self.allKmers.append(key)

            if key not in self.nodes:
                self.nodes.update({key: kmers.get(key)})  # kmer wird hinzugefügt

                #print(key)
                for edge in DBGnode(key).get_potential_to():
                    if edge in self.nodes or edge ==key:
                        self.edges.add((key, edge))
                        #print(key, " ", edge)
                for edge in DBGnode(key).get_potential_from():
                    if edge in self.nodes:
                        self.edges.add((edge, key))
                        #print(key, " ", edge)

    # 2 Punkte
    def count_edges(self):
        return len(self.edges)
    # 1 Punkt
    def count_nodes(self):
        return len(self.nodes)
    # 1 Punkt
    def __str__(self):
        x=self.kmerlength
        y=len(self.nodes)
        z=len(self.edges)
        return x+" kmer größe\n"+y+" k-mere/Knoten\n"+z+" Kanten"


def read_fasta(readfile):
    with open( readfile, 'r') as readfile:
        readList = []
        buffer = []
        for line in readfile:
            if line.startswith(">"):
                if buffer:
                    readList.append(Read(buffer))
                buffer = [line]
            else:
                buffer.append(line.strip())
        if buffer:
            readList.append(Read(buffer))
        return readList

# 3 Punkte
def build_graph(filename, kmersize):
    result=DBGraph()
    file = read_fasta(filename)
    for seq in file:
        result.add_kmers(seq.get_kmers(kmersize))
#        print("\n",result.__str__())
    return result

if __name__ == "__main__":
    graph = build_graph("data/test.fasta", 2)
    print()

"""
Textaufgabe:

Bei "Anzahl der Kanten = Anzahl der k-mere - 1" ist der Graph eine "Treppe". Nur ein Pfad

Ja, das Rekonstruieren wird einfacher sein, da man mehr Möglichkeiten hat, um k-mere zu kombinieren.
Je näher die Anzahl Kanten an der Anzahl k-mere ist, desto signifikanter wird jedes einzelne k-mer 
und ein "ausfallender" k-mer wirkt sich schlimmer auf die Rekonstruktion aus.
"""