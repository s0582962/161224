class Sequence:
    def __init__(self, lines):
        self.name = lines[0].strip()[1:]
        self.bases = "".join([x.strip() for x in lines[1:]]).upper()

    def __str__(self):
        return self.name + ": " + self.bases[:20] + "..."

    def __repr__(self):
        return self.__str__()


class Read(Sequence):
    def get_seed(self, seedlength):
        return self.bases[:seedlength]

    """
    Erweitern Sie zudem die Klasse Read um die Methode replace_kmers(self, replacements), 
    welche die dictionary aus get_replacements bekommt und alle darin als key vorkommenden k-mere, 
    die in dem Read vorhanden sind, durch den jeweiligen value ersetzt. 
    """

    def replace_kmers(self, replacements):
        #replacements = {old : new, old : new}
        #new soll in self.bases

        for key,value in replacements.items():
            if key in self.bases:
                oldLine = self.bases.split(key,1)
                self.bases = oldLine[0]+value+oldLine[1]

class Reference(Sequence):
    def __init__(self, lines):
        self.kmers = None
        super().__init__(lines)

    def get_kmer_positions(self, kmer):
        if self.kmers is None or len(next(iter(self.kmers))) != len(kmer):
            self.calculate_kmers(len(kmer))
        if kmer not in self.kmers:
            return []
        return self.kmers[kmer]
    def calculate_kmers(self, kmersize):
        self.kmers = {}
        for pos in range(0, len(self.bases) - kmersize + 1):
            kmer = self.bases[pos:(pos + kmersize)]
            if kmer not in self.kmers:
                self.kmers[kmer] = []
            self.kmers[kmer] += [pos]
    def count_mismatches(self, read, position):
        mismatches = 0
        for pos in range(position, position+len(read.bases)):
            if pos >= len(self.bases):
                break
            if read.bases[pos-position] != self.bases[pos]:
                mismatches += 1
        # Count every base of the read that goes out past the end of the reference as a mismatch
        mismatches += position+len(read.bases)-pos-1
        return mismatches


class Mapping:
    def __init__(self, reference):
        self.reference = reference
        self.reads = {}

    def add_read(self, read, position):
        if position not in self.reads:
            self.reads[position] = []
        self.reads[position] += [read]

    def get_reads_at_position(self, position):
        if position not in self.reads:
            return []
        return self.reads[position]

    def __str__(self):
        res = ["Mapping to " + self.reference.name]
        for pos in self.reads:
            res += ["  " + str(len(self.reads[pos])) + " reads mapping at " + str(pos)]
        return "\n".join(res)

class SAMWriter:
    def __init__(self, mapping):
        self.mapping = mapping
    """Schreibt das Mapping in das angegebene SAM-File"""
    def write_mapping(self, filename):
        with open(filename, "w") as file:
            #(Header)
            #@SQ	SN:GQ359764.1	LN:2445
            """
            Die Felder SN: und LN: geben den Namen der Referenzsequenz 
            (muss exakt der Name aus der verwendeten Referenz-FASTA-Datei bis zum ersten Leerzeichen sein) 
            und ihre Länge an.
            """
            header = "@SQ\tSN:"+self.mapping.reference.name.split()[0]+"\tLN:"+str(len(self.mapping.reference.bases))+"\n"
            file.write(header)
            for key, values in self.mapping.reads.items():
                                #value ist liste aus readobjects und key ist position
                for read in values:
                    index1 = read.name  # QNAME
                    index2 = str(0)  # FLAG Bitweiser Flag. 0 für "mappt korrekt", nicht0 für inkorrekt
                    index3 = self.mapping.reference.name.split()[0]  # RNAME Name der Referenzsequenz (identisch mit SN: in @SQ-Header)
                    index4 = str(key+1)  # POS Position in der Referenz (erste Base ist 1, nicht 0)
                    index5 = str(255)  # MAPQ Mapping Qualität
                    index6 = str(len(read.bases))+"M"  # CIGAR 	CIGAR-String des Alignments
                    index7 = "*"  # RNEXT next read
                    index8 = str(0)  # PNEXT position next
                    index9 = str(0)  # TLEN insert length
                    index10 = read.bases  # SEQ Readsequenz
                    index11 = "*"  # QUAL Basen-Qualität der Reads (wie in FASTQ-Datei)
                    line = "\t".join([index1,index2,index3,index4,index5,index6,index7,index8,index9,index10,index11])+"\n"
#                    line= index1+"\t"+ index2+"\t"+ index3+"\t"+ index4+"\t"+ index5+"\t"+index6+"\t"+ index7+"\t"+ index8+"\t"+ index9+"\t"+ index10+"\t"+ index11+"\n"
                    file.write(line)
        file.close()


class ReadPolisher:
    """
    __init__(self, kmerlen): Constructor, bekommt die zu verwendende k-mer-Länge
add_read(self, readseq): Fügt die übergebene Readsequenz dem k-mer-Spektrum hinzu
get_replacements(self, minfreq): Berechnet für die k-mere, die seltener als minfreq
 im k-mer-Spektrum vorkommen, die mögliche Korrektur und gibt ein entsprechendes dictionary zurück.
 Darin sind keys die korrigierbaren k-mere, values sind die Korrekturen (in dem obigen
 Beispiel wäre also z.B. bei minfreq=2 ein mögliches key-value-Paar "GCT":"GTT", welches aussagt,
 dass das k-mer "GCT" durch das k-mer "GTT" ersetzt werden soll)
    """
    def __init__(self, kmerlen):
        self.kmerlen = kmerlen
        self.spektrumKmers = {}

    def get_spektrum(self):
        return self.spektrumKmers

    def add_read(self, readseq):
        z=1     #teilread kommt z male vor
        #l=len(readseq) - self.kmerlen + 1
        for i in range(len(readseq) - self.kmerlen + 1):
            teilread = ""
            c = 0
            for j in range(self.kmerlen):
                teilread += readseq[i + c]
                c += 1
            if teilread in self.spektrumKmers.keys():
                z = self.spektrumKmers.get(teilread) + 1
            self.spektrumKmers.update({teilread: z})

    def get_replacements(self, minfreq):
        result = {}
        for key, value in self.spektrumKmers.items():
            if value < minfreq: #minimal frequency, Anzahl wie oft vorkommt
                ersatzbank = []
                x = 0           #stelle im read-string-key
                for baseX in key:
                    for baseY in ["A","G","T","C"]:
                        ersatz=""
                        for i in range(len(key)):
                            if i == x:
                                if baseY == baseX:  #wenn char durch selben char ersetzt
                                    continue
                                ersatz+= baseY
                            else:
                                ersatz+= key[i] #rest vom String bleibt so wie vorher

                        if ersatz in self.spektrumKmers.keys():
                            #ersatzbank.append(ersatz)
                            if self.spektrumKmers.get(ersatz) >= minfreq:
                                result.update({key: ersatz})

                    x+=1

                #result.update({key:ersatzbank})

        return result


def read_fasta(fastafile, klassname):
    klass = globals()[klassname]
    f = open(fastafile, "r")
    readlines = []
    reads = []
    for line in f:
        if line[0] == '>' and len(readlines) != 0:
            reads += [klass(readlines)]
            readlines = []
        readlines += [line]
    reads += [klass(readlines)]
    f.close()
    return reads


def map_reads(reads, reference, kmersize, max_mismatches):
    mapping = Mapping(reference)
    reference.calculate_kmers(kmersize)
    for read in reads:
        seed = read.get_seed(kmersize)
        seed_positions = reference.get_kmer_positions(seed)
        for position in seed_positions:
            mismatches = reference.count_mismatches(read, position)
            if mismatches < max_mismatches:
                mapping.add_read(read, position)
    return mapping


def main():

    for i in range(4):
        if i != 2:
            continue
        reads = read_fasta("data/patient"+str(i+1)+".fasta", Read.__name__)
        p = ReadPolisher(3) #(kmerlength)
        for read in reads:
            p.add_read(read.bases)
            read.replace_kmers(p.get_replacements(15))   #(frequency-Cutoff)
        reference = read_fasta("data/rpoB.fasta", Reference.__name__)[0]
        mapping = map_reads(reads, reference, 8, 5)
        w = SAMWriter(mapping)
        w.write_mapping("data/patient"+str(i+1)+"polishedX.sam")
    #print("Mapping reads: " + len(mapping.reads))


if __name__ == "__main__":
   main()
