import sys
class Sequence:
    # 2 Punkte
    """"__init__(self, lines): Constructor, wie in Read aus dem Assembler. Denken Sie dabei allerdings daran, \
    dass FASTA-Dateien nach einer Header-Zeile beliebig viele Sequenzzeilen haben können
    (wie es beispielsweise in "data/fluA.fasta" der Fall ist). Speichern Sie die Sequenz unter
    self.bases und den Read Namen und self.name"""

    def __init__(self, lines):
        self.lines = lines           #zeile besteht aus ">x Sequenz"
        self.name = self.getName()
        self.bases = self.get_bases()        #Sequenz
    def getName(self):
        result=self.lines[0][1::].strip('\n')
        return result

    def get_bases(self):
        result=""
        for i in range(1,len(self.lines)):
            result += self.lines[i]
            result = result.strip('\n')

        return result
    def getTrimmedSequence(self):
        result = ": "
        for i in range(len(self.bases)):
            if i == 20:
                result += "..."
                break
            result += self.bases[i]
        return result
    def __str__(self):
        result =self.getName()+self.getTrimmedSequence()
        return result

    """__repr__(self): Wie in Read aus dem Assembler, die von __str__ definierte String-Repräsentation zurück."""
    def __repr__(self):
        return self.__str__()

# 1 Punkt
class Read(Sequence):
    def get_seed(self, seedlength):
        return self.bases[:seedlength]


class Reference(Sequence):
    """calculate_kmers(self, kmersize): Berechnet ein Dictionary aller in der Referenz enthaltenen k-mere
     der Länge kmersize als Key und alle kmer Positionen in der Referenz als Value und speichert dieses
     unter self.kmerDict.
    get_kmer_positions(self, kmer): Gibt alle Positionen zurück, an denen das k-mer kmer in der Sequenz vorkommt.
    count_mismatches(self, read, position): Gibt zurück, wie viele mismatches es zwischen dem Read read
    (als Read-Objekt übergeben, nicht als string!) und der Sequenz an der Position position gibt.
    Ragt der Read über die Sequenz hinaus (z.B. wie wenn in dem oberen Beispiel die Anzahl der mismatches
    zwischen dem 1. Read und dem Referenzgenom an Position 13 berechnet werden sollte), werden alle Basen
    des Reads die über das Referenzgenom hinausragen als mismatches gezählt.
    """
    #1 Punkt
    def __init__(self, lines):
        super().__init__(lines)

    #3 Punkte
    def calculate_kmers(self, kmersize):
        result= {}
        for i in range(len(self.bases)-kmersize-1):
            line=""
            c=0
            for j in range(kmersize):
                line+=self.bases[i+c]
                c+=1
            value = result.get(line),i
            result.update({line:value})
        return result

    # 2 Punkte
    def get_kmer_positions(self, kmer):
        result = []
        for i in range(len(self.bases)-len(kmer)):
            check=True
            for j in range(len(kmer)):
                if self.bases[i+j] != kmer[j]:
                    check = False
                    break
            if check==True:
                result.append(i)
        return result

    # 2 Punkte
    def count_mismatches(self, read, position):
        result = 0
        for i in range(len(read.bases)-1):
            if self.bases[position + i] != read.bases[i] or position + i > len(self.bases):
                result+=1
        return result

class Mapping:
    """
* ```__init__(self, reference)```: Der Constructor, der die Referenzsequenz bekommt, auf die gemappt wird.
* ```add_read(self, read, position)```: Fügt dem Mapping an der Position ```position```
den Read ```read``` hinzu. Werfen Sie einen `ValueError`, wenn wenn `position` nicht zwischen 0
 und der Länge der Referenz - 1 liegt.
* ```get_reads_at_position(self, position)```: Gibt die Liste der an der Position ```position```
 mappenden Reads zurück (also der Reads, deren Mapping an dieser Position beginnt, und nicht aller
 Reads, die an dieser Position eine Base haben - im obigen Beispiel würde also die Liste der an
 Position 3 mappenden Reads nur aus Read 2 bestehen, _nicht_ aus Read 1 und Read 2).
    """
    # 3 Punkte
    def __init__(self, reference):
        self.reference = reference  #reference objekt
        self.map = dict()       #alle Hinzugefügten Reads mit Anfangspositionen
    # 2 Punkte
    def add_read(self, read, position):
        if position < 0 or position > len(self.reference.bases)-1:
            ValueError("Position ungültig")
        self.map.update({read:position})

    # 3 Punkte
    def get_reads_at_position(self, position):
        result = [key for key, value in self.map.items() if value == position]
        return result

    def __str__(self):
        return "<MappingObject> Reference:{}, # Reads: {}".format(self.reference.name, len(self.reads))


# 4 Punkte
def read_fasta(fastafile, klassname):
    with open(fastafile, 'r') as readfile:
        readList = []
        buffer = []
        for line in readfile:
            if line.startswith(">"):
                if buffer:
                    readList.append(klassname(buffer))
                buffer = [line]
            else:
                buffer.append(line.strip())
        if buffer:
            readList.append(klassname(buffer))
        return readList

# 6 Punkte
def map_reads(reads, reference, kmersize, max_mismatches):
    """Die Funktion ```map_reads(reads, reference, kmersize, max_mismatches)```
    soll die ```Read```s aus der Liste ```reads``` auf die ```Reference``` aus
    ```reference``` unter Verwendung der seed-Länge ```kmersize``` und einer
    Maximal-mismatch-Anzahl von ```max_mismatches``` mappen und das resultierende
    ```Mapping```-Objekt zurückgeben. """

    result = Mapping(reference)
    kmers = result.reference.calculate_kmers(kmersize)
    for read in reads:
        seed = read.get_seed(kmersize)
        if seed in kmers.keys():
            positions = result.reference.get_kmer_positions(seed)
            for position in positions:
                mismatches = result.reference.count_mismatches(read,position)
                if mismatches <= max_mismatches:
                    result.add_read(read,position)

    return result #mapping Objekt




def main():
    reads = read_fasta("data/fluA_reads.fasta", Read.__name__)
    reference = read_fasta("data/fluA.fasta", Reference.__name__)[0]
    mapping = map_reads(reads, reference, 8, 2)
    print(mapping)


if __name__ == "__main__":
    main()
