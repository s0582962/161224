


# --- Aufgabe 1: List Comprehensions ---
# Punkte: 0
# Um list comprehensions zu üben, spielen wir ein wenig code-golf: Jede der Aufgaben lässt sich mit einer Zeile
# lösen. Beispielsweise wäre die Lösung, um bei einer übergebenen Liste mit unterschiedlichen Zahlen eine Liste
# nur mit den Zahlen größer x zurückzugeben:
def example_list_comprehension(numbers, x):             #passed
    return [value for value in numbers if value > x]

# Punkte: 1
# Geben Sie ein Array zurück, das in jedem Element der Reihe nach einen Buchstaben des Textes enthält. Beispiel:
# text = "test", result = ["t", "e", "s", "t"].
# Lösen Sie diese Aufgabe in einer Zeile unter Verwendung einer list comprehension!
def text_to_array(text):            #passed
    return [char for char in text]

# Punkte: 3
# Geben Sie ein array zurück, dass revers-komplementär zum Eingabe Array ist.
# Ersetzen Sie nicht Standard RNA Zeichen ("A","C","U","G") zu 'N'
# sequence_array = ["A","C","U","G","Q"], result =["N","C","A","G","U"]
# Nutzen Sie auch hier ausschließlich ein einzeilige list comprehension!
def reverse_complement_RNA_array(sequence_array):                   #passed
    return ["U" if char=="A" else "C" if char=="G" else "A" if char=="U" else "G" if char=="C" else "N" for char in sequence_array[::-1]]

# Punkte: 2
# Geben Sie zurück, wie häufig das Zeichen needle im string haystack vorkommt.
# Lösen Sie diese Aufgabe in einer Zeile unter Verwendung einer list comprehension!
# Bitte nicht einfach string.count verwenden!
# Es soll ein einzelner integer zurückgegeben werden.
def count_needle(haystack, needle):         #nicht passed aber eig richtig?
    return len([char for char in haystack if (char == needle)])

# Punkte: 1
# Geben Sie eine Liste mit allen ungeraden Zahlen kleiner als maxnumber zurück.
# Lösen Sie diese Aufgabe in einer Zeile unter Verwendung einer list comprehension!
def odd_numbers(maxnumber):             #passed
    return [i for i in range(maxnumber) if i%2==1]

# Punkte: 3
# Geben Sie eine Liste mit allen Primzahlen kleiner als maxnumber zurück.
# Denken Sie daran, dass Sie list comprehensions verschachteln dürfen!
# Lösen Sie diese Aufgabe in einer Zeile unter Verwendung einer list comprehension!
def primes(maxnumber):              #passed
    return [x for x in range(maxnumber) if not any([x % y == 0 for y in range(2, int(x/2)+1)]) and (x!=1) and (x!=0)]


# --- Aufgabe 2: Generatoren ---
# Punkte 1
# Schreiben Sie einen Generator, der ungerade Zahlen zurückgibt
def odd_numbers_generator():                    #passed
    for i in range(1,10,2):
        yield i

# Punkte 2
# Schreiben Sie einen Generator, der die Fibonacci-Folge liefert
# Hinweis: Sie können yield überall in der Generator-Funktion verwenden.
def fibonacci_generator():              #passed
    result = [0,1]
    for i in range(1,10):
        result.append(result[i] + result[i-1])
        yield result[i-1]
