#! /usr/bin/python3

import sys

# 8 Punkte
class Read:
    '''* Einen Constructor, der als String-Array die ihn beschreibenden Zeilen aus einer FASTA-Datei bekommt. Speichern
    Sie den Sequenznamen als `name` und die Sequenz als `bases` im Objekt ab.
* ```get_kmers(self, kmersize)```: Gibt alle k-mere der Länge k des Reads als dictionary zurück. Key soll dabei die
    Sequenz des k-mers sein, value die Häufigkeit (also wie viel Mal dieses k-mer in der Read-Sequenz vorkommt)
* ```__str__(self)```: Gibt den Read als String aus, in der Form "Name: Sequenz", wobei bei Sequenzen mit einer Länge
    von mehr als 20 Basen nur die ersten 20 Basen, gefolgt von "..." ausgegeben werden sollen. Beispiel: "Read 2:
    AGTCGTAGCGTACCGTAGCC..." Beachten Sie: Das '>' ist nicht Teil des Namens & Whitespaces sind nicht Teil der Sequenz!
* ```__repr__(self)```: Gibt die in ```__str__``` definierte String-Repräsentation zurück (für eine einfachere Ausgabe
    auf der Kommandozeile)
* ```__eq__(self, other)```: Der Vergleichsoperator, der aufgerufen wird, wenn zwei Objekte mit ```==``` miteinander
    verglichen werden. Soll'''
    def __init__(self, lines):
        self.lines = lines           #zeile besteht aus ">x Sequenz"
        self.name = self.getName()
        self.bases = self.get_bases()        #Sequenz
    def getName(self):
        result=""
        head = self.lines[0]
        for i in range(1,len(head)):    #skipps the ">"
            if head[i] == "\"":
                break
            result+=head[i]
        return result
    def get_bases(self):
        result=""
        for i in range(1,len(self.lines)):
            result += self.lines[i]
        return result
    def get_kmers(self, kmersize):  #kmersize = länge eines einzelnen kmers
        result={}
        resKmers=[]
        kmer=""
        for i in range(len(self.bases)):
            if i + kmersize >= len(self.bases):  ##prüfe ob Index noch in der Sequenz liegt
                break
            for j in range(0,kmersize):
                kmer+=self.bases[i+j]
            resKmers.append(kmer)
            kmer = ""
        for i in range(len(resKmers)):
            needlesinHay = self.bases.count(resKmers[i])            #Anzahl übereinstimmungen mit bases finden
            result.update({resKmers[i]: needlesinHay})              #füge beides in Dictionary hinzu
        return result
    def getTrimmedSequence(self):
        result = ": "
        for i in range(len(self.bases)):
            if i == 20:
                result += "..."
                break
            result += self.bases[i]
        return result
    def __str__(self):
        result =self.getName()+self.getTrimmedSequence()
        #x=self.getTrimmedSequence()
        #result = self.name+x
        #print("b",result.__class__)
        return result
    def __repr__(self):
        result =  str(self)
        #print(result.__class__)
        return result
    def __eq__(self, other):    #???
        if not isinstance(other, Read):
            return False
        if other.name != self.name:
            return False
        if other.bases != self.bases:
            return False
        return True

# 10 Punkte
class DBGnode:
    '''
Die Klasse DBGNode soll einen Knoten im De Bruijn-Graph repräsentieren - also ein k-mer mit einer Liste von ein-
und ausgehenden Kanten. Implementieren Sie dafür die folgenden Methoden:
                        * Einen Constructor, der die Sequenz des Knotens bekommt (also seine k-mer-Sequenz)
                        * ```get_potential_from(self)```: Gibt als Liste alle k-mer-Sequenzen zurück, von denen es theoretisch eine Kante zu
                        diesem Knoten geben könnte. Bedenken Sie, was die Definition eines De Bruijn-Graphen ist: Wenn wir das Alphabet
                    ```["A", "G", "T", "C"]``` nutzen, können diese potentiellen Knoten sehr einfach aufgelistet werden!
                         * ```get_potential_to(self)```: Gibt, ähnlich ```get_potential_from(self)```, die Liste aller k-mer-Sequenzen zurück,
                          zu denen von diesem Knoten aus eine Kante gehen könnte.
                        * ```add_edge_to(self, eto)```: Fügt zu der internen Kantenliste eine Kante zu der ```DBGNode``` ```eto``` hinzu.
                        Falls diese Kante schon existiert, wird stattdessen ihr Gewicht um 1 erhöht.
                        * ```add_edge_from(self, efrom)```: Fügt zu der internen Kantenliste eine Kante von der ```DBGNode``` ```efrom``` hinzu.
                        Falls diese Kante schon existiert, wird stattdessen ihr Gewicht um 1 erhöht.
* ```get_edge_from_weight(self, other)```: Gibt das Gewicht der Kante von der ```DBGNode``` ```other``` zu diesem Knoten
zurück (0, falls keine solche Kante existiert).
* ```get_edge_to_weight(self, other)```: Gibt das Gewicht der Kante von diesem Knoten zur ```DBGNode``` ```other```
zurück (0, falls keine solche Kante existiert).
'''

    def __init__(self, kmer):
        self.kmer = kmer    #ein kmer (teil von Sequenz)
        self.edgesTo = {}  #DBGNode: weight, key: value
        self.edgesFrom = {}  # DBGNode: weight, key: value
        self.alphabet = ["A", "G", "T", "C"]

    def add_edge_to(self, eto):
        if self.edgesTo.get(eto.kmer) == None:
            self.edgesTo.update({eto.kmer: 1})    #+1
        else:
            self.edgesTo[eto.kmer] += 1
    def add_edge_from(self, efrom):
        if self.edgesFrom.get(efrom.kmer) == None:
            self.edgesFrom.update({efrom.kmer: 1})    #+1
        else:
            self.edgesFrom[efrom.kmer] += 1
    def get_potential_from(self):
        result=[]
        for e in range(len(self.alphabet)):
            node = self.alphabet[e]+self.kmer[0:len(self.kmer)-1]
            result.append(node)
        return result
    def get_potential_to(self):
        result = []
        for e in range(len(self.alphabet)):
            node = self.kmer[1:len(self.kmer)] + self.alphabet[e]
            result.append(node)
        return result

    def get_edge_to_weight(self, other):
        result = self.edgesTo.get(other.kmer) or 0
        return result
    def get_edge_from_weight(self, other):
        result = self.edgesFrom.get(other.kmer) or 0
        return result

# 4 Punkte
'''Das Einlesen der gesamten FASTA-Datei soll in der top-level-Methode ```read_fasta(filename)``` erfolgen, die als
    ``filename``` den Pfad zu einer FASTA-Datei bekommt und eine Liste von ```Read```-Objekten zurückgibt, die die
    einzelnen Reads aus der FASTA-Datei enthalten.
'''
def read_fasta(readfile):
    result =[]
    name=""
    base=""
    j=0
    with open(readfile, 'r') as file:
        lines = file.readlines()
        for i in range(0,len(lines)):
            if lines[i][0]==">": #Namenszeile
                name=lines[i][:len(lines[i])-1]     #remove \n
                j+=1
            else:
                base = lines[i][:len(lines[i])-1]
                j+=1
            if j==2:
                einzelnerRead = Read([name,base])
                result.append(einzelnerRead)
                j=0
    return result


if __name__ == "__main__":
    r = read_fasta("data/test.fasta")
    e = read_fasta("data/virus_perfectreads.fasta")
    #for i in range(len(r)):
    #    print(r[i])
