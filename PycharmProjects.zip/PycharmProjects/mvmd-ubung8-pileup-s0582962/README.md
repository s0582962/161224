# Mutationen erkennen

Um mehrere Datensätze miteinander vergleichen zu können, wäre es aber gut, solche Unterschiede nicht rein mit dem Auge zu erkennen. Um das Erkennen von Mutationen einfacher zu machen, kann ein Mapping auch im pileup-Format geschrieben werden. Im Pileup-Format werden positionsweise die Basen aufgezählt, die in der Referenz sowie in den diese Position abdeckenden Reads vorkommen. Das Pileup des folgenden Alignments (ähnlich wie das obere Alignment, nur mit zwei Abweichungen zwischen Reads und Referenz mehr):

```text
AGTGCTAGCGTTA
  TGCTCGCGT
    CTAGC
     TCGCA
```

sähe wie folgt aus:

```text
ref     1       A       0
ref     2       G       0
ref     3       T       1       .
ref     4       G       1       .
ref     5       C       2       ..
ref     6       T       3       ...
ref     7       A       3       C.C
ref     8       G       3       ...
ref     9       C       3       ...
ref     10      G       2       .A
ref     11      T       1       .
ref     12      T       0
ref     13      A       0
```

Jede Zeile beschreibt eine Position im Referenzgenom, die Zeilen sind aufsteigend nach Position sortiert. Die Spalten sind tabulator-getrennt und enthalten die folgende Information:

| Nummer | Name | Beschreibung |
|---|---|---|
| 1 | Name | Name der Referenzsequenz |
| 2 | Position | Nummer der Base in der Referenzsequenz, beginnend bei 1 |
| 3 | Referenzbase | Base in der Referenzsequenz an dieser Position |
| 4 | Readanzahl | Anzahl der Reads, die diese Position abdecken |
| 5 | Readbasen | Basen in den Reads an dieser Position. `.` für "gleiche Base wie Referenz", sonst die Base des Reads |

Unterschiede zwischen Referenz und Reads lassen sich an diesem Dateiformat deutlich einfacher erkennen und prozessieren.

## Mapping erweitern

Erweitern Sie zunächst die Klasse `Mapping` um eine Methode `get_pileup(self)`, die ein Pileup des Mappings als Array zurückgibt. Dabei soll jedes Element des Arrays die Spalten 2-5 repräsentieren. Beispielsweise wäre das Array für die ersten 7 Zeilen des oben gezeigten pileups wie folgt:

```[[1, 'A', 0, ''], [2, 'G', 0, ''], [3, 'T', 1, '.'], [4, 'G', 1, '.'], [5, 'C', 2, '..'], [6, 'T', 3, '...'], [7, 'A', 3, 'C.C']]```

Erweitern Sie zudem die Klasse `Mapping` um die Methode `write_pileup(self, filename)`,
die ein durch `get_pileup()` erstelltes Pileup im oben dargestellten, Tabstopp getrennten,
Format in die Datei `filename` schreibt. Um Arbeitsspeicher zu sparen schreiben Sie die Datenschnellst möglich aus,
ohne den Inhalt erst in einem Puffer zwischen zu speichern.